class Node
  attr_accessor :data, :next_node

  def initialize(data)
    @data = data
    @next_node = nil
  end
end

class LinkedList
  attr_accessor :head

  def initialize
    @head = nil
  end

  def is_empty?
    @head.nil?
  end

  def append(data)
    new_node = Node.new(data)
    if @head.nil?
      @head = new_node
    else
      last_node.next_node = new_node
    end
  end

  def prepend(data)
    new_node = Node.new(data)
    new_node.next_node = @head
    @head = new_node
  end

  def size
    count = 0
    current_node = @head
    while current_node
      count += 1
      current_node = current_node.next_node
    end
    count
  end

  def display
    current_node = @head
    while current_node
      print "#{current_node.data} -> "
      current_node = current_node.next_node
    end
    puts "nil"
  end

  private

  def last_node
    current_node = @head
    while current_node.next_node
      current_node = current_node.next_node
    end
    current_node
  end
end

# Взаємодія з користувачем
linked_list = LinkedList.new

loop do
  puts "\nОберіть операцію:"
  puts "1. Додати елемент в кінець списку"
  puts "2. Додати елемент на початок списку"
  puts "3. Вивести розмір списку"
  puts "4. Вивести вміст списку"
  puts "5. Вийти"

  choice = gets.chomp.to_i

  case choice
  when 1
    print "Введіть дані для додавання в кінець списку: "
    data = gets.chomp
    linked_list.append(data)
  when 2
    print "Введіть дані для додавання на початок списку: "
    data = gets.chomp
    linked_list.prepend(data)
  when 3
    puts "Розмір списку: #{linked_list.size}"
  when 4
    puts "Вміст списку:"
    linked_list.display
  when 5
    puts "Дякую за використання програми. До побачення!"
    break
  else
    puts "Невірний вибір. Спробуйте ще раз."
  end
end
